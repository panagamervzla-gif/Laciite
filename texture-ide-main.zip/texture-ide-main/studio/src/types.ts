export interface ProjectRecord {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  fileCount: number;
  directories: string[];
  dictionaryPath: string;
}

export interface ProjectFile {
  projectId: string;
  path: string;
  blob: Blob;
  mimeType: string;
  kind: 'source' | 'dictionary';
}

export interface DictionaryAsset {
  id: string;
  path: string;
  hashes: string[];
  name: string;
  tags: string[];
  description: string;
}

export interface TextureDictionary {
  format: 'texture-workbench-dictionary';
  version: 1;
  assets: DictionaryAsset[];
}

export interface ImportedPackage {
  name: string;
  files: ProjectFile[];
  directories: string[];
  dictionaryPath: string;
  dictionary: TextureDictionary;
  dictionaryText: string;
}