import JSZip from 'jszip';
import type { DictionaryAsset, ImportedPackage, ProjectFile, TextureDictionary } from './types';

const dictionaryFileName = 'texture-dictionary.txt';
const textureIniFileName = 'textures.ini';
const imageExtensions = new Set(['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'tga', 'dds']);

function normalizePath(path: string): string {
  return path.replaceAll('\\', '/').replace(/^\.\//, '').replace(/^\/+/, '');
}

function parentPath(path: string): string {
  const slash = path.lastIndexOf('/');
  return slash < 0 ? '' : path.slice(0, slash + 1);
}

function isImage(path: string): boolean {
  return imageExtensions.has(path.split('.').at(-1)?.toLowerCase() ?? '');
}

function mimeType(path: string): string {
  const extension = path.split('.').at(-1)?.toLowerCase();
  return ({
    png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp',
    gif: 'image/gif', bmp: 'image/bmp', tga: 'image/x-tga', dds: 'image/vnd-ms.dds'
  } as Record<string, string>)[extension ?? ''] ?? 'application/octet-stream';
}

function parseTextureMappings(text: string): Map<string, string> {
  const mappings = new Map<string, string>();
  let inHashes = false;
  for (const line of text.split(/\r?\n/)) {
    const section = line.match(/^\s*\[([^\]]+)\]\s*$/);
    if (section) {
      inHashes = section[1].toLowerCase() === 'hashes';
      continue;
    }
    if (!inHashes || /^\s*[#;]/.test(line)) continue;
    const mapping = line.match(/^\s*([\da-f]{8,})\s*=\s*(.*?)\s*(?:[#;].*)?$/i);
    if (mapping && mapping[2]) mappings.set(mapping[1].toLowerCase(), normalizePath(mapping[2].trim()));
  }
  return mappings;
}

function parseDictionary(text: string): TextureDictionary {
  const value: unknown = JSON.parse(text);
  if (!value || typeof value !== 'object') throw new Error(`${dictionaryFileName} no contiene un objeto JSON válido.`);
  const source = value as Partial<TextureDictionary>;
  if (source.format !== 'texture-workbench-dictionary' || source.version !== 1 || !Array.isArray(source.assets)) {
    throw new Error(`${dictionaryFileName} tiene un formato que esta versión no reconoce.`);
  }
  return {
    format: 'texture-workbench-dictionary',
    version: 1,
    assets: source.assets.map((asset: DictionaryAsset) => ({
      id: typeof asset.id === 'string' && asset.id ? asset.id : crypto.randomUUID(),
      path: normalizePath(typeof asset.path === 'string' ? asset.path : ''),
      hashes: Array.isArray(asset.hashes) ? asset.hashes.filter((hash): hash is string => typeof hash === 'string') : [],
      name: typeof asset.name === 'string' ? asset.name : '',
      tags: Array.isArray(asset.tags) ? asset.tags.filter((tag): tag is string => typeof tag === 'string') : [],
      description: typeof asset.description === 'string' ? asset.description : ''
    }))
  };
}

function createDictionary(texturesIni: string, packagePaths: string[], iniPath: string, existingText?: string): TextureDictionary {
  const existing = existingText
    ? parseDictionary(existingText)
    : { format: 'texture-workbench-dictionary' as const, version: 1 as const, assets: [] };
  const iniRoot = parentPath(iniPath);
  const pathLookup = new Map(packagePaths.map(path => [path.toLowerCase(), path]));
  const hashesByPath = new Map<string, string[]>();

  for (const [hash, target] of parseTextureMappings(texturesIni)) {
    const normalizedTarget = normalizePath(target);
    const candidates = [normalizePath(`${iniRoot}${normalizedTarget}`), normalizedTarget];
    const matchedPath = candidates.map(candidate => pathLookup.get(candidate.toLowerCase())).find(Boolean)
      ?? packagePaths.find(path => path.toLowerCase().endsWith(`/${normalizedTarget.toLowerCase()}`));
    if (matchedPath) hashesByPath.set(matchedPath, [...(hashesByPath.get(matchedPath) ?? []), hash]);
  }

  const assets: DictionaryAsset[] = [];
  for (const path of packagePaths) {
    if (!isImage(path) && !hashesByPath.has(path)) continue;
    const hashes = [...new Set(hashesByPath.get(path) ?? [])];
    const previous = existing.assets.find(asset => asset.path.toLowerCase() === path.toLowerCase())
      ?? existing.assets.find(asset => asset.hashes.some(hash => hashes.includes(hash)));
    assets.push({
      id: previous?.id ?? crypto.randomUUID(),
      path,
      hashes,
      name: previous?.name ?? '',
      tags: previous?.tags ?? [],
      description: previous?.description ?? ''
    });
  }
  const currentPaths = new Set(assets.map(asset => asset.path.toLowerCase()));
  for (const previous of existing.assets) {
    if (!currentPaths.has(previous.path.toLowerCase())) assets.push(previous);
  }
  return { format: 'texture-workbench-dictionary', version: 1, assets };
}

export async function importPackage(file: File, projectId: string): Promise<ImportedPackage> {
  const zip = await JSZip.loadAsync(file);
  const archiveFiles = Object.entries(zip.files).filter(([, entry]) => !entry.dir);
  const iniEntry = archiveFiles.find(([path]) => path.split('/').at(-1)?.toLowerCase() === textureIniFileName);
  const iniPath = iniEntry?.[0] ?? '';
  const packageRoot = parentPath(iniPath);
  const sidecar = archiveFiles.find(([path]) => path.split('/').at(-1)?.toLowerCase() === dictionaryFileName);
  const dictionaryPath = sidecar?.[0] ?? `${packageRoot}${dictionaryFileName}`;
  const iniText = iniEntry ? await zip.file(iniPath)!.async('string') : '';
  const existingDictionaryText = sidecar ? await zip.file(sidecar[0])!.async('string') : undefined;
  const packagePaths = archiveFiles.map(([path]) => path);
  const dictionary = createDictionary(iniText, packagePaths, iniPath, existingDictionaryText);
  const dictionaryText = `${JSON.stringify(dictionary, null, 2)}\n`;
  const files: ProjectFile[] = [];

  for (const [path] of archiveFiles) {
    const isDictionary = path === dictionaryPath;
    const blob = isDictionary
      ? new Blob([dictionaryText], { type: 'text/plain;charset=utf-8' })
      : new Blob([await zip.file(path)!.async('arraybuffer')], { type: mimeType(path) });
    files.push({ projectId, path, blob, mimeType: isDictionary ? 'text/plain' : mimeType(path), kind: isDictionary ? 'dictionary' : 'source' });
  }
  if (!sidecar) {
    files.push({
      projectId,
      path: dictionaryPath,
      blob: new Blob([dictionaryText], { type: 'text/plain;charset=utf-8' }),
      mimeType: 'text/plain',
      kind: 'dictionary'
    });
  }

  const directories = Object.entries(zip.files).filter(([, entry]) => entry.dir).map(([path]) => path.replace(/\/$/, ''));
  return {
    name: file.name.replace(/\.zip$/i, '') || 'Proyecto importado',
    files,
    directories,
    dictionaryPath,
    dictionary,
    dictionaryText
  };
}

export function createEmptyDictionary(): TextureDictionary {
  return { format: 'texture-workbench-dictionary', version: 1, assets: [] };
}

export function validateDictionary(text: string): TextureDictionary {
  return parseDictionary(text);
}

export async function exportPackage(files: ProjectFile[], directories: string[], name: string): Promise<void> {
  const zip = new JSZip();
  for (const directory of directories) zip.folder(directory);
  for (const file of files) zip.file(file.path, await file.blob.arrayBuffer());
  const output = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 5 } });
  const url = URL.createObjectURL(output);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${name.replace(/\.zip$/i, '')}.zip`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}