import { openDB, type DBSchema } from 'idb';
import type { ProjectFile, ProjectRecord } from './types';

interface TextureWorkbenchDB extends DBSchema {
  projects: { key: string; value: ProjectRecord };
  files: { key: [string, string]; value: ProjectFile; indexes: { 'by-project': string } };
}

const database = openDB<TextureWorkbenchDB>('texture-workbench', 1, {
  upgrade(db) {
    db.createObjectStore('projects', { keyPath: 'id' });
    db.createObjectStore('files', { keyPath: ['projectId', 'path'] }).createIndex('by-project', 'projectId');
  }
});

export async function listProjects(): Promise<ProjectRecord[]> {
  const db = await database;
  return (await db.getAll('projects')).sort((left, right) => right.updatedAt - left.updatedAt);
}

export async function getProject(projectId: string): Promise<ProjectRecord | undefined> {
  return (await database).get('projects', projectId);
}

export async function getProjectFiles(projectId: string): Promise<ProjectFile[]> {
  const db = await database;
  return (await db.getAllFromIndex('files', 'by-project', projectId)).sort((left, right) => left.path.localeCompare(right.path));
}

export async function createProject(project: ProjectRecord, files: ProjectFile[]): Promise<void> {
  const db = await database;
  const transaction = db.transaction(['projects', 'files'], 'readwrite');
  await transaction.objectStore('projects').put(project);
  for (const file of files) await transaction.objectStore('files').put(file);
  await transaction.done;
}

export async function saveProject(project: ProjectRecord): Promise<void> {
  await (await database).put('projects', { ...project, updatedAt: Date.now() });
}

export async function saveProjectFiles(project: ProjectRecord, files: ProjectFile[]): Promise<void> {
  const db = await database;
  const transaction = db.transaction(['projects', 'files'], 'readwrite');
  for (const file of files) await transaction.objectStore('files').put(file);
  await transaction.objectStore('projects').put({ ...project, updatedAt: Date.now() });
  await transaction.done;
}

export async function saveProjectFile(project: ProjectRecord, file: ProjectFile): Promise<void> {
  const db = await database;
  const transaction = db.transaction(['projects', 'files'], 'readwrite');
  await transaction.objectStore('files').put(file);
  await transaction.objectStore('projects').put({ ...project, updatedAt: Date.now() });
  await transaction.done;
}