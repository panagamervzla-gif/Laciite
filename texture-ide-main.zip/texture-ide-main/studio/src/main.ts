import './styles.css';
import { createEmptyDictionary, exportPackage, importPackage, validateDictionary } from './archive';
import { createProject, getProject, getProjectFiles, listProjects, saveProject, saveProjectFile, saveProjectFiles } from './storage';
import type { ProjectFile, ProjectRecord, TextureDictionary } from './types';

interface ProjectTreeNode {
  name: string;
  path: string;
  children: Map<string, ProjectTreeNode>;
  files: ProjectFile[];
  itemCount: number;
}

const libraryView = document.querySelector<HTMLElement>('#libraryView')!;
const projectView = document.querySelector<HTMLElement>('#projectView')!;
const projectList = document.querySelector<HTMLElement>('#projectList')!;
const emptyLibrary = document.querySelector<HTMLElement>('#emptyLibrary')!;
const libraryStatus = document.querySelector<HTMLElement>('#libraryStatus')!;
const projectCount = document.querySelector<HTMLElement>('#projectCount')!;
const projectName = document.querySelector<HTMLElement>('#projectName')!;
const projectMeta = document.querySelector<HTMLElement>('#projectMeta')!;
const topbarProject = document.querySelector<HTMLElement>('#topbarProject')!;
const topbarActions = document.querySelector<HTMLElement>('#topbarActions')!;
const workspaceTabs = document.querySelector<HTMLElement>('#workspaceTabs')!;
const managerTab = document.querySelector<HTMLButtonElement>('#managerTab')!;
const fileCount = document.querySelector<HTMLElement>('#fileCount')!;
const fileList = document.querySelector<HTMLElement>('#fileList')!;
const folderGrid = document.querySelector<HTMLElement>('#folderGrid')!;
const browserPath = document.querySelector<HTMLElement>('#browserPath')!;
const workbench = document.querySelector<HTMLElement>('#workbench')!;
const dictionaryPane = document.querySelector<HTMLElement>('#dictionaryPane')!;
const showDictionaryButton = document.querySelector<HTMLButtonElement>('#showDictionaryButton')!;
const closeDictionaryButton = document.querySelector<HTMLButtonElement>('#closeDictionaryButton')!;
const fileSearch = document.querySelector<HTMLInputElement>('#fileSearch')!;
const selectedFileName = document.querySelector<HTMLElement>('#selectedFileName')!;
const selectedFileKind = document.querySelector<HTMLElement>('#selectedFileKind')!;
const assetFacts = document.querySelector<HTMLElement>('#assetFacts')!;
const dictionaryEditor = document.querySelector<HTMLTextAreaElement>('#dictionaryEditor')!;
const dictionaryStatus = document.querySelector<HTMLElement>('#dictionaryStatus')!;
const dictionaryAssetCount = document.querySelector<HTMLElement>('#dictionaryAssetCount')!;
const saveState = document.querySelector<HTMLElement>('#saveState')!;
const openPhotopeaButton = document.querySelector<HTMLButtonElement>('#openPhotopeaButton')!;
const photopeaDialog = document.querySelector<HTMLDialogElement>('#photopeaDialog')!;
const photopeaFrame = document.querySelector<HTMLIFrameElement>('#photopeaFrame')!;
const photopeaFileName = document.querySelector<HTMLElement>('#photopeaFileName')!;
const photopeaStatus = document.querySelector<HTMLElement>('#photopeaStatus')!;
const saveFromPhotopeaButton = document.querySelector<HTMLButtonElement>('#saveFromPhotopeaButton')!;
const zipInput = document.querySelector<HTMLInputElement>('#zipInput')!;
const filesInput = document.querySelector<HTMLInputElement>('#filesInput')!;

let activeProject: ProjectRecord | undefined;
let activeFiles: ProjectFile[] = [];
let activeDictionary: TextureDictionary | undefined;
let selectedPath = '';
let selectedDirectory = '';
let expandedDirectories = new Set<string>(['']);
let editorTimer = 0;
const photopeaOrigin = 'https://www.photopea.com';
let photopeaFilePath = '';
let photopeaOutputFormat = 'png';
let photopeaPhase: 'closed' | 'booting' | 'opening' | 'ready' | 'saving' = 'closed';
let pendingPhotopeaSave = false;
let photopeaOpenBuffer: ArrayBuffer | undefined;

function setLibraryStatus(message: string, error = false): void {
  libraryStatus.textContent = message;
  libraryStatus.classList.toggle('error', error);
}

function setSaveState(message: string, kind: 'saved' | 'busy' | 'error' = 'saved'): void {
  saveState.textContent = message;
  saveState.dataset.state = kind;
}

function newId(): string {
  return crypto.randomUUID();
}

function makeDictionaryFile(project: ProjectRecord, dictionary: TextureDictionary): ProjectFile {
  const text = `${JSON.stringify(dictionary, null, 2)}\n`;
  return {
    projectId: project.id,
    path: project.dictionaryPath,
    blob: new Blob([text], { type: 'text/plain;charset=utf-8' }),
    mimeType: 'text/plain',
    kind: 'dictionary'
  };
}

async function renderLibrary(): Promise<void> {
  const projects = await listProjects();
  projectList.replaceChildren();
  projectCount.textContent = `${projects.length} proyecto${projects.length === 1 ? '' : 's'}`;
  emptyLibrary.hidden = false;
  for (const project of projects) {
    const row = document.createElement('button');
    row.className = 'project-row';
    row.type = 'button';
    const identity = document.createElement('span');
    identity.className = 'project-identity';
    const mark = document.createElement('span');
    mark.className = 'project-mark';
    mark.textContent = '▦';
    const name = document.createElement('strong');
    name.textContent = project.name;
    identity.append(mark, name);
    const files = document.createElement('span');
    files.className = 'project-files-count';
    files.textContent = `${project.fileCount} archivos`;
    const modified = document.createElement('time');
    modified.className = 'project-date';
    modified.textContent = new Date(project.updatedAt).toLocaleString();
    row.append(identity, files, modified);
    row.addEventListener('click', () => void openProject(project.id).catch(error => setLibraryStatus(errorMessage(error), true)));
    projectList.append(row);
  }
  projectList.append(emptyLibrary);
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : 'Ocurrió un error inesperado.';
}

async function createBlankProject(): Promise<void> {
  const now = Date.now();
  const project: ProjectRecord = {
    id: newId(),
    name: 'Nuevo proyecto',
    createdAt: now,
    updatedAt: now,
    fileCount: 1,
    directories: [],
    dictionaryPath: 'texture-dictionary.txt'
  };
  const dictionary = createEmptyDictionary();
  await createProject(project, [makeDictionaryFile(project, dictionary)]);
  await openProject(project.id);
  await requestPersistentStorage();
}

async function importZipFile(file: File): Promise<void> {
  setLibraryStatus(`Importando ${file.name}…`);
  const id = newId();
  const imported = await importPackage(file, id);
  const now = Date.now();
  const project: ProjectRecord = {
    id,
    name: imported.name,
    createdAt: now,
    updatedAt: now,
    fileCount: imported.files.length,
    directories: imported.directories,
    dictionaryPath: imported.dictionaryPath
  };
  await createProject(project, imported.files);
  await openProject(id);
  await requestPersistentStorage();
  setLibraryStatus(`Proyecto creado desde ${file.name}. El ZIP original no se modificó.`);
}

async function requestPersistentStorage(): Promise<void> {
  if (!navigator.storage?.persist) return;
  try {
    const persisted = await navigator.storage.persist();
    setSaveState(persisted ? 'Almacenamiento persistente' : 'Guardado local');
  } catch {
    setSaveState('Guardado local');
  }
}

async function openProject(projectId: string): Promise<void> {
  const project = await getProject(projectId);
  if (!project) throw new Error('No se encontró el proyecto en este navegador.');
  activeProject = project;
  activeFiles = await getProjectFiles(projectId);
  selectedPath = '';
  selectedDirectory = '';
  expandedDirectories = new Set(['']);
  document.body.classList.add('project-active');
  libraryView.hidden = true;
  projectView.hidden = false;
  topbarProject.textContent = project.name;
  topbarProject.hidden = false;
  topbarActions.hidden = false;
  workspaceTabs.hidden = false;
  projectName.textContent = project.name;
  projectMeta.textContent = `${project.fileCount} archivos · guardado en este navegador`;
  const sidecar = activeFiles.find(file => file.path === project.dictionaryPath);
  if (!sidecar) {
    const created = makeDictionaryFile(project, createEmptyDictionary());
    await saveProjectFile(project, created);
    activeFiles.push(created);
    activeProject = { ...activeProject, fileCount: activeFiles.length };
    await saveProject(activeProject);
    dictionaryEditor.value = await created.blob.text();
  } else {
    dictionaryEditor.value = await sidecar.blob.text();
  }
  try {
    activeDictionary = validateDictionary(dictionaryEditor.value);
    updateDictionaryCount();
    dictionaryStatus.textContent = project.dictionaryPath;
    dictionaryStatus.classList.remove('error');
  } catch {
    activeDictionary = undefined;
    dictionaryStatus.textContent = 'Diccionario no válido; corrige el JSON para guardar.';
    dictionaryStatus.classList.add('error');
  }
  setDictionaryVisible(false);
  renderProjectExplorer();
  setSaveState('Guardado local');
}

function buildProjectTree(): ProjectTreeNode {
  const root: ProjectTreeNode = { name: activeProject?.name ?? 'Proyecto', path: '', children: new Map(), files: [], itemCount: 0 };
  for (const file of activeFiles) {
    const parts = file.path.split('/').filter(Boolean);
    const fileName = parts.pop();
    let node = root;
    let currentPath = '';
    for (const part of parts) {
      currentPath = currentPath ? `${currentPath}/${part}` : part;
      if (!node.children.has(part)) node.children.set(part, { name: part, path: currentPath, children: new Map(), files: [], itemCount: 0 });
      node = node.children.get(part)!;
    }
    if (fileName) node.files.push(file);
  }
  const countItems = (node: ProjectTreeNode): number => {
    node.itemCount = node.files.length;
    for (const child of node.children.values()) node.itemCount += countItems(child);
    return node.itemCount;
  };
  countItems(root);
  return root;
}

function findDirectory(root: ProjectTreeNode, path: string): ProjectTreeNode | undefined {
  if (!path) return root;
  let current = root;
  for (const part of path.split('/')) {
    const next = current.children.get(part);
    if (!next) return undefined;
    current = next;
  }
  return current;
}

function renderFolderBranch(container: HTMLElement, node: ProjectTreeNode, depth = 0): void {
  for (const child of node.children.values()) {
    const row = document.createElement('div');
    row.className = 'folder-tree-row';
    row.style.paddingLeft = `${depth * 12}px`;
    const toggle = document.createElement('button');
    toggle.className = 'tree-toggle';
    toggle.type = 'button';
    toggle.disabled = child.children.size === 0;
    toggle.textContent = child.children.size ? (expandedDirectories.has(child.path) ? '⌄' : '›') : '·';
    toggle.setAttribute('aria-label', `Expandir o contraer ${child.name}`);
    toggle.addEventListener('click', () => {
      if (expandedDirectories.has(child.path)) expandedDirectories.delete(child.path);
      else expandedDirectories.add(child.path);
      renderFileTree();
    });
    const select = document.createElement('button');
    select.className = `tree-folder${selectedDirectory === child.path ? ' active' : ''}`;
    select.type = 'button';
    select.textContent = `▱ ${child.name}`;
    select.title = child.path;
    select.addEventListener('click', () => selectDirectory(child.path));
    row.append(toggle, select);
    container.append(row);
    if (child.children.size && expandedDirectories.has(child.path)) {
      const branch = document.createElement('div');
      branch.className = 'folder-tree-branch';
      container.append(branch);
      renderFolderBranch(branch, child, depth + 1);
    }
  }
}

function renderFileTree(): void {
  fileList.replaceChildren();
  const root = buildProjectTree();
  const rootRow = document.createElement('button');
  rootRow.className = `file-row${selectedDirectory === '' ? ' active' : ''}`;
  rootRow.type = 'button';
  rootRow.innerHTML = '<span class="file-row-icon">▱</span><span class="file-row-name">Proyecto</span>';
  rootRow.addEventListener('click', () => selectDirectory(''));
  fileList.append(rootRow);
  if (expandedDirectories.has('')) renderFolderBranch(fileList, root);
}

function renderBrowser(): void {
  const root = buildProjectTree();
  const current = findDirectory(root, selectedDirectory) ?? root;
  const query = fileSearch.value.trim().toLowerCase();
  folderGrid.replaceChildren();
  browserPath.replaceChildren();

  const pathParts = [{ label: 'Proyecto', path: '' }];
  let accumulated = '';
  for (const part of selectedDirectory.split('/').filter(Boolean)) {
    accumulated = accumulated ? `${accumulated}/${part}` : part;
    pathParts.push({ label: part, path: accumulated });
  }
  for (const [index, part] of pathParts.entries()) {
    if (index) {
      const separator = document.createElement('span');
      separator.className = 'path-separator';
      separator.textContent = '›';
      browserPath.append(separator);
    }
    const crumb = document.createElement('button');
    crumb.className = `path-crumb${index === pathParts.length - 1 ? ' path-current' : ''}`;
    crumb.type = 'button';
    crumb.textContent = part.label;
    crumb.addEventListener('click', () => selectDirectory(part.path));
    browserPath.append(crumb);
  }

  let shown = 0;
  for (const child of current.children.values()) {
    if (query && !child.name.toLowerCase().includes(query) && !child.path.toLowerCase().includes(query)) continue;
    const card = document.createElement('button');
    card.className = 'folder-card';
    card.type = 'button';
    const art = document.createElement('span');
    art.className = 'folder-art';
    art.textContent = '▱';
    const footer = document.createElement('span');
    footer.className = 'folder-card-footer';
    const label = document.createElement('strong');
    label.textContent = child.name;
    const count = document.createElement('small');
    count.textContent = `${child.itemCount} elementos`;
    footer.append(label, count);
    card.append(art, footer);
    card.addEventListener('click', () => selectDirectory(child.path));
    folderGrid.append(card);
    shown += 1;
  }
  const visibleFiles = current.files.filter(file => !query || file.path.toLowerCase().includes(query));
  for (const file of visibleFiles) {
    const card = document.createElement('button');
    card.className = `project-file-card${file.path === selectedPath ? ' selected' : ''}`;
    card.type = 'button';
    const icon = document.createElement('span');
    icon.className = 'project-file-icon';
    icon.textContent = file.kind === 'dictionary' ? '≡' : file.mimeType.startsWith('image/') ? '▧' : `.${file.path.split('.').at(-1)?.slice(0, 4).toUpperCase() ?? 'FILE'}`;
    const name = document.createElement('span');
    name.textContent = file.path.split('/').at(-1) ?? file.path;
    name.title = file.path;
    card.append(icon, name);
    card.addEventListener('click', () => selectFile(file.path));
    folderGrid.append(card);
    shown += 1;
  }
  fileCount.textContent = `${shown} elementos`;
  if (shown === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-folder';
    empty.textContent = query ? 'No hay elementos que coincidan.' : 'Esta carpeta está vacía.';
    folderGrid.append(empty);
  }
}

function renderProjectExplorer(): void {
  renderFileTree();
  renderBrowser();
}

function selectDirectory(path: string): void {
  selectedDirectory = path;
  selectedPath = '';
  openPhotopeaButton.disabled = true;
  if (path) expandedDirectories.add(path);
  renderProjectExplorer();
}

function updateDictionaryCount(): void {
  const count = activeDictionary?.assets.length ?? 0;
  dictionaryAssetCount.textContent = `${count} ficha${count === 1 ? '' : 's'}`;
}

function setDictionaryVisible(visible: boolean): void {
  dictionaryPane.hidden = !visible;
  workbench.classList.toggle('dictionary-closed', !visible);
  showDictionaryButton.hidden = visible;
  showDictionaryButton.setAttribute('aria-pressed', String(visible));
  showDictionaryButton.title = visible ? 'Diccionario visible' : 'Mostrar diccionario';
  showDictionaryButton.setAttribute('aria-label', showDictionaryButton.title);
}

function selectFile(path: string): void {
  selectedPath = path;
  const file = activeFiles.find(item => item.path === path);
  if (!file) return;
  const supportedPhotopeaImage = /\.(png|jpe?g|webp|gif)$/i.test(file.path) && file.mimeType.startsWith('image/');
  openPhotopeaButton.disabled = !supportedPhotopeaImage;
  selectedFileName.textContent = file.path.split('/').at(-1) ?? file.path;
  selectedFileKind.textContent = file.kind === 'dictionary' ? 'DICCIONARIO' : file.mimeType || 'ARCHIVO';
  const asset = activeDictionary?.assets.find(item => item.path === file.path);
  assetFacts.textContent = asset
    ? `${asset.hashes.length} hashes · ${asset.name || 'Sin nombre descriptivo'}${asset.tags.length ? ` · ${asset.tags.join(', ')}` : ''}${asset.description ? ` · ${asset.description}` : ''}`
    : file.kind === 'dictionary' ? 'Metadata portable del proyecto.' : 'Sin ficha de diccionario asociada.';
  renderBrowser();
}

function outputSettings(path: string): { format: string; mimeType: string } | undefined {
  const extension = path.split('.').at(-1)?.toLowerCase();
  if (extension === 'jpg' || extension === 'jpeg') return { format: 'jpg', mimeType: 'image/jpeg' };
  if (extension === 'webp') return { format: 'webp', mimeType: 'image/webp' };
  if (extension === 'gif') return { format: 'gif', mimeType: 'image/gif' };
  if (extension === 'png') return { format: 'png', mimeType: 'image/png' };
  return undefined;
}

async function openSelectedInPhotopea(): Promise<void> {
  if (!activeProject || !selectedPath) return;
  const file = activeFiles.find(item => item.path === selectedPath);
  const output = outputSettings(selectedPath);
  if (!file || !output) return;

  photopeaFilePath = file.path;
  photopeaOutputFormat = output.format;
  photopeaOpenBuffer = await file.blob.arrayBuffer();
  pendingPhotopeaSave = false;
  photopeaPhase = 'booting';
  photopeaFileName.textContent = file.path;
  photopeaStatus.textContent = 'Conectando con Photopea…';
  saveFromPhotopeaButton.disabled = true;

  const configuration = {
    environment: {
      intro: false,
      localsave: false,
      customIO: {
        open: 'app.echoToOE("texture-workbench:open");',
        save: `app.echoToOE("texture-workbench:save");app.activeDocument.saveToOE("${output.format}");`
      }
    },
    script: `app.activeDocument.source = ${JSON.stringify(file.path)};`
  };
  photopeaDialog.showModal();
  photopeaFrame.src = `${photopeaOrigin}#${encodeURIComponent(JSON.stringify(configuration))}`;
}

async function handlePhotopeaMessage(event: MessageEvent): Promise<void> {
  if (event.origin !== photopeaOrigin || event.source !== photopeaFrame.contentWindow) return;

  if (event.data === 'done') {
    if (photopeaPhase === 'booting' && photopeaOpenBuffer) {
      photopeaPhase = 'opening';
      photopeaStatus.textContent = 'Abriendo textura…';
      photopeaFrame.contentWindow?.postMessage(photopeaOpenBuffer, photopeaOrigin);
      photopeaOpenBuffer = undefined;
    } else if (photopeaPhase === 'opening') {
      photopeaPhase = 'ready';
      saveFromPhotopeaButton.disabled = false;
      photopeaStatus.textContent = 'Listo · Guardar en Photopea actualiza el proyecto';
    } else if (photopeaPhase === 'saving') {
      photopeaPhase = 'ready';
      saveFromPhotopeaButton.disabled = false;
      photopeaStatus.textContent = 'Textura guardada en el proyecto';
    }
    return;
  }

  if (typeof event.data === 'string') {
    if (event.data === 'texture-workbench:save') {
      pendingPhotopeaSave = true;
      photopeaPhase = 'saving';
      saveFromPhotopeaButton.disabled = true;
      photopeaStatus.textContent = 'Recibiendo textura…';
    } else if (event.data === 'texture-workbench:open') {
      photopeaStatus.textContent = 'Abre texturas desde el gestor del proyecto para conservar el vínculo.';
    }
    return;
  }

  if (!(event.data instanceof ArrayBuffer) || !pendingPhotopeaSave || !activeProject || !photopeaFilePath) return;
  pendingPhotopeaSave = false;
  const existing = activeFiles.find(file => file.path === photopeaFilePath);
  if (!existing) {
    photopeaStatus.textContent = 'El archivo ya no está en el proyecto.';
    return;
  }

  try {
    const blob = new Blob([event.data], { type: outputSettings(photopeaFilePath)?.mimeType ?? 'image/png' });
    const updated: ProjectFile = { ...existing, blob };
    await saveProjectFile(activeProject, updated);
    activeFiles = activeFiles.map(file => file.path === photopeaFilePath ? updated : file);
    selectedPath = photopeaFilePath;
    renderProjectExplorer();
    selectFile(photopeaFilePath);
    photopeaStatus.textContent = 'Textura guardada en IndexedDB';
    setSaveState('Guardado local');
  } catch (error) {
    photopeaStatus.textContent = errorMessage(error);
    setSaveState('Error al guardar textura', 'error');
  }
}

function requestPhotopeaSave(): void {
  if (photopeaPhase !== 'ready') return;
  pendingPhotopeaSave = true;
  photopeaPhase = 'saving';
  saveFromPhotopeaButton.disabled = true;
  photopeaStatus.textContent = 'Solicitando exportación…';
  const command = `app.echoToOE("texture-workbench:save");app.activeDocument.saveToOE("${photopeaOutputFormat}");`;
  photopeaFrame.contentWindow?.postMessage(command, photopeaOrigin);
}

function closePhotopea(): void {
  photopeaPhase = 'closed';
  pendingPhotopeaSave = false;
  photopeaOpenBuffer = undefined;
  photopeaFilePath = '';
  saveFromPhotopeaButton.disabled = true;
  photopeaDialog.close();
  photopeaFrame.src = 'about:blank';
  managerTab.classList.add('active');
}

async function saveDictionary(): Promise<void> {
  if (!activeProject) return;
  const dictionary = validateDictionary(dictionaryEditor.value);
  const file = makeDictionaryFile(activeProject, dictionary);
  activeDictionary = dictionary;
  activeFiles = activeFiles.filter(item => item.path !== file.path);
  activeFiles.push(file);
  activeProject = { ...activeProject, fileCount: activeFiles.length, updatedAt: Date.now() };
  await saveProjectFile(activeProject, file);
  await saveProject(activeProject);
  dictionaryStatus.textContent = `Guardado · ${new Date().toLocaleTimeString()}`;
  dictionaryStatus.classList.remove('error');
  setSaveState('Guardado local');
  projectMeta.textContent = `${activeProject.fileCount} archivos · guardado en este navegador`;
  updateDictionaryCount();
  if (selectedPath === file.path) selectFile(file.path);
}

function handleDictionaryInput(): void {
  window.clearTimeout(editorTimer);
  setSaveState('Validando…', 'busy');
  editorTimer = window.setTimeout(() => {
    void saveDictionary().catch(error => {
      dictionaryStatus.textContent = errorMessage(error);
      dictionaryStatus.classList.add('error');
      setSaveState('Cambios sin guardar', 'error');
    });
  }, 700);
}

async function addFiles(files: FileList | File[]): Promise<void> {
  if (!activeProject) return;
  const additions: ProjectFile[] = [];
  const existing = new Set(activeFiles.map(file => file.path.toLowerCase()));
  for (const source of [...files]) {
    const dot = source.name.lastIndexOf('.');
    const stem = dot > 0 ? source.name.slice(0, dot) : source.name;
    const extension = dot > 0 ? source.name.slice(dot) : '';
    let path = source.name;
    let suffix = 2;
    while (existing.has(path.toLowerCase())) {
      path = `${stem} (${suffix})${extension}`;
      suffix += 1;
    }
    existing.add(path.toLowerCase());
    additions.push({ projectId: activeProject.id, path, blob: source, mimeType: source.type || 'application/octet-stream', kind: 'source' });
  }
  if (!additions.length) return;
  activeFiles.push(...additions);
  activeProject = { ...activeProject, fileCount: activeFiles.length, updatedAt: Date.now() };
  await saveProjectFiles(activeProject, additions);
  const imageFiles = additions.filter(file => file.mimeType.startsWith('image/'));
  if (activeDictionary && imageFiles.length) {
    for (const file of imageFiles) activeDictionary.assets.push({ id: newId(), path: file.path, hashes: [], name: '', tags: [], description: '' });
    dictionaryEditor.value = `${JSON.stringify(activeDictionary, null, 2)}\n`;
    await saveDictionary();
  }
  projectMeta.textContent = `${activeProject.fileCount} archivos · guardado en este navegador`;
  renderProjectExplorer();
  setSaveState('Guardado local');
}

async function exportActiveProject(): Promise<void> {
  if (!activeProject) return;
  try {
    setSaveState('Preparando ZIP…', 'busy');
    validateDictionary(dictionaryEditor.value);
    await saveDictionary();
    const files = await getProjectFiles(activeProject.id);
    await exportPackage(files, activeProject.directories, activeProject.name);
    setSaveState('ZIP exportado');
  } catch (error) {
    setSaveState(errorMessage(error), 'error');
    dictionaryStatus.textContent = errorMessage(error);
    dictionaryStatus.classList.add('error');
  }
}

async function openLibrary(): Promise<void> {
  activeProject = undefined;
  activeFiles = [];
  activeDictionary = undefined;
  selectedPath = '';
  selectedDirectory = '';
  document.body.classList.remove('project-active');
  projectView.hidden = true;
  topbarProject.hidden = true;
  topbarActions.hidden = true;
  workspaceTabs.hidden = true;
  libraryView.hidden = false;
  await renderLibrary();
}

document.querySelector<HTMLButtonElement>('#openZipButton')!.addEventListener('click', () => zipInput.click());
zipInput.addEventListener('change', () => {
  const file = zipInput.files?.[0];
  if (!file) return;
  void importZipFile(file).then(() => setLibraryStatus('')).catch(error => setLibraryStatus(errorMessage(error), true));
  zipInput.value = '';
});
document.querySelector<HTMLButtonElement>('#createProjectButton')!.addEventListener('click', () => {
  void createBlankProject().catch(error => setLibraryStatus(errorMessage(error), true));
});
document.querySelector<HTMLButtonElement>('#homeButton')!.addEventListener('click', event => {
  event.preventDefault();
  void openLibrary();
});
document.querySelector<HTMLButtonElement>('#backToLibrary')!.addEventListener('click', () => void openLibrary());
managerTab.addEventListener('click', () => {
  if (photopeaDialog.open) closePhotopea();
  managerTab.classList.add('active');
});
emptyLibrary.addEventListener('click', () => {
  void createBlankProject().catch(error => setLibraryStatus(errorMessage(error), true));
});
document.querySelector<HTMLButtonElement>('#addFilesButton')!.addEventListener('click', () => filesInput.click());
filesInput.addEventListener('change', () => {
  if (filesInput.files) void addFiles(filesInput.files).catch(error => setSaveState(errorMessage(error), 'error'));
  filesInput.value = '';
});
showDictionaryButton.addEventListener('click', () => setDictionaryVisible(true));
closeDictionaryButton.addEventListener('click', () => setDictionaryVisible(false));
document.querySelector<HTMLButtonElement>('#exportProjectButton')!.addEventListener('click', () => void exportActiveProject());
document.querySelector<HTMLButtonElement>('#saveDictionaryButton')!.addEventListener('click', () => {
  void saveDictionary().catch(error => {
    dictionaryStatus.textContent = errorMessage(error);
    dictionaryStatus.classList.add('error');
  });
});
openPhotopeaButton.addEventListener('click', () => {
  managerTab.classList.remove('active');
  void openSelectedInPhotopea().catch(error => {
    photopeaStatus.textContent = errorMessage(error);
    setSaveState('No se pudo abrir Photopea', 'error');
  });
});
saveFromPhotopeaButton.addEventListener('click', requestPhotopeaSave);
document.querySelector<HTMLButtonElement>('#closePhotopeaButton')!.addEventListener('click', closePhotopea);
photopeaDialog.addEventListener('cancel', event => {
  event.preventDefault();
  closePhotopea();
});
window.addEventListener('message', event => {
  void handlePhotopeaMessage(event).catch(error => {
    photopeaStatus.textContent = errorMessage(error);
    setSaveState('Error al guardar textura', 'error');
  });
});
dictionaryEditor.addEventListener('input', handleDictionaryInput);
fileSearch.addEventListener('input', renderProjectExplorer);

void renderLibrary().catch(error => setLibraryStatus(errorMessage(error), true));